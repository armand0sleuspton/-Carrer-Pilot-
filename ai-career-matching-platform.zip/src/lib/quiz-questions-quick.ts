import type { QuizQuestion } from "./quiz-data";

// Quick Assessment: 15 carefully selected questions (~5 minutes)
// Covers the most essential dimensions for accurate matching

export const quickQuestions: QuizQuestion[] = [
  {
    id: "quick_1",
    category: "Personality",
    type: "scenario",
    question: "It's Saturday morning with nothing planned. What pulls you out of bed?",
    subtitle: "Choose what feels most natural—not what sounds impressive.",
    options: [
      { value: "creative_project", label: "A creative project I've been thinking about", emoji: "🎨" },
      { value: "social_plans", label: "Texting friends to make spontaneous plans", emoji: "👋" },
      { value: "learn_something", label: "A podcast or article that caught my attention", emoji: "📚" },
      { value: "outdoor_adventure", label: "Getting outside—hiking, cycling, exploring", emoji: "🏔️" },
      { value: "nothing", label: "Honestly? Nothing. I'd stay in bed.", emoji: "😴" },
      { value: "organize", label: "Tidying up and getting my life organized", emoji: "📋" },
    ],
  },
  {
    id: "quick_2",
    category: "Career Interests",
    type: "multiple",
    question: "Which activities would you genuinely enjoy doing for hours?",
    subtitle: "Select all that apply. Be honest—not aspirational.",
    options: [
      { value: "analyze_data", label: "Analyzing patterns in data", emoji: "📊" },
      { value: "design_things", label: "Designing or creating visual things", emoji: "🎨" },
      { value: "help_people", label: "Helping people solve personal problems", emoji: "💛" },
      { value: "build_things", label: "Building or coding something from scratch", emoji: "🔨" },
      { value: "write", label: "Writing—stories, essays, or content", emoji: "✍️" },
      { value: "debate", label: "Debating ideas and persuading others", emoji: "💬" },
      { value: "research", label: "Deep-diving into a topic until I understand everything", emoji: "🔬" },
      { value: "organize_events", label: "Organizing events or managing projects", emoji: "📅" },
    ],
  },
  {
    id: "quick_3",
    category: "Values",
    type: "multiple-top3",
    question: "What matters most to you in your future career?",
    subtitle: "Select your top 3 priorities.",
    options: [
      { value: "money", label: "High salary & financial security", emoji: "💰" },
      { value: "impact", label: "Making a positive impact on the world", emoji: "🌍" },
      { value: "creativity", label: "Creative freedom & self-expression", emoji: "🎭" },
      { value: "prestige", label: "Recognition & status", emoji: "⭐" },
      { value: "balance", label: "Work-life balance & flexibility", emoji: "⚖️" },
      { value: "growth", label: "Constant learning & personal growth", emoji: "📈" },
    ],
  },
  {
    id: "quick_4",
    category: "Big Five",
    type: "likert",
    question: "I feel energized after spending time with a large group of people.",
    options: [
      { value: "1", label: "Strongly Disagree" },
      { value: "2", label: "Disagree" },
      { value: "3", label: "Neutral" },
      { value: "4", label: "Agree" },
      { value: "5", label: "Strongly Agree" },
    ],
  },
  {
    id: "quick_5",
    category: "Big Five",
    type: "likert",
    question: "I like to have a clear plan before starting any task.",
    options: [
      { value: "1", label: "Strongly Disagree" },
      { value: "2", label: "Disagree" },
      { value: "3", label: "Neutral" },
      { value: "4", label: "Agree" },
      { value: "5", label: "Strongly Agree" },
    ],
  },
  {
    id: "quick_6",
    category: "Work Style",
    type: "single",
    question: "Your ideal workspace looks like:",
    options: [
      { value: "home_alone", label: "My own room at home—quiet and private", emoji: "🏠" },
      { value: "coffee_shop", label: "A busy coffee shop with ambient noise", emoji: "☕" },
      { value: "open_office", label: "An open-plan office with colleagues", emoji: "🏢" },
      { value: "lab", label: "A lab or workshop with equipment", emoji: "🔬" },
      { value: "outdoors", label: "Outdoors or constantly on the move", emoji: "🌳" },
      { value: "co_working", label: "A co-working space with diverse people", emoji: "💡" },
    ],
  },
  {
    id: "quick_7",
    category: "Leadership",
    type: "scenario",
    question: "In a group project, you naturally tend to:",
    options: [
      { value: "lead", label: "Take charge and organize everyone", emoji: "👑" },
      { value: "ideas", label: "Generate ideas and creative solutions", emoji: "💡" },
      { value: "execute", label: "Put my head down and do the work", emoji: "⚡" },
      { value: "mediate", label: "Keep the peace and make sure everyone's heard", emoji: "🕊️" },
      { value: "quality", label: "Review and improve the quality of work", emoji: "🔍" },
      { value: "support", label: "Support others and help where needed", emoji: "🤝" },
    ],
  },
  {
    id: "quick_8",
    category: "Risk & Ambition",
    type: "slider",
    question: "How strong is your desire to start your own business one day?",
    sliderConfig: { min: 1, max: 10, step: 1, labels: ["Not at all", "Maybe someday", "It's my dream"] },
  },
  {
    id: "quick_9",
    category: "Learning Style",
    type: "single",
    question: "When learning something completely new, what's your instinct?",
    options: [
      { value: "read", label: "Read everything about it first", emoji: "📖" },
      { value: "watch", label: "Watch someone else do it", emoji: "👀" },
      { value: "try", label: "Jump in and try—learn by doing", emoji: "🚀" },
      { value: "discuss", label: "Discuss it with someone who knows", emoji: "💬" },
      { value: "structure", label: "Find a structured course or guide", emoji: "📝" },
    ],
  },
  {
    id: "quick_10",
    category: "Long-term Goals",
    type: "scenario",
    question: "Fast forward 10 years. What does success look like?",
    subtitle: "Choose the one that resonates most deeply.",
    options: [
      { value: "ceo", label: "Leading a company or organization", emoji: "👔" },
      { value: "expert", label: "Being a world-renowned expert in my field", emoji: "🎓" },
      { value: "creative", label: "Having creative freedom and a portfolio I'm proud of", emoji: "🎨" },
      { value: "impact", label: "Having measurably improved people's lives", emoji: "🌍" },
      { value: "lifestyle", label: "A comfortable life with great relationships", emoji: "🏖️" },
      { value: "innovator", label: "Having built something innovative that changes the game", emoji: "🚀" },
    ],
  },
  {
    id: "quick_11",
    category: "University Life",
    type: "single",
    question: "Your ideal university experience includes:",
    options: [
      { value: "vibrant_social", label: "A vibrant social scene with lots of events", emoji: "🎉" },
      { value: "academic_focused", label: "Academic excellence above everything", emoji: "🎓" },
      { value: "balanced", label: "A perfect balance of fun and studying", emoji: "⚖️" },
      { value: "small_community", label: "A small, tight-knit community", emoji: "🏡" },
      { value: "independent", label: "Freedom to do my own thing", emoji: "🦅" },
      { value: "innovative", label: "Innovation, startups, and hackathons", emoji: "🚀" },
    ],
  },
  {
    id: "quick_12",
    category: "City Preferences",
    type: "multiple",
    question: "What matters most to you in the city where you'll study?",
    subtitle: "Select your top priorities.",
    options: [
      { value: "safety", label: "Safety & cleanliness", emoji: "🛡️" },
      { value: "nightlife", label: "Great nightlife & social scene", emoji: "🌙" },
      { value: "nature", label: "Access to nature & green spaces", emoji: "🌲" },
      { value: "affordable", label: "Affordable cost of living", emoji: "💰" },
      { value: "career", label: "Career opportunities & internships", emoji: "💼" },
      { value: "diversity", label: "Cultural diversity", emoji: "🌍" },
    ],
  },
  {
    id: "quick_13",
    category: "Financial",
    type: "single",
    question: "What best describes your financial situation for university?",
    subtitle: "This helps us recommend realistic options.",
    options: [
      { value: "no_concern", label: "Money isn't a concern", emoji: "💎" },
      { value: "some_support", label: "Family support + part-time work", emoji: "🤝" },
      { value: "scholarship_needed", label: "I'll need scholarships or financial aid", emoji: "🎓" },
      { value: "self_funded", label: "I'll mostly fund it myself", emoji: "💪" },
      { value: "unsure", label: "I'm not sure yet", emoji: "🤔" },
    ],
    allowSkip: true,
  },
  {
    id: "quick_14",
    category: "International",
    type: "slider",
    question: "How far from home are you willing to study?",
    sliderConfig: { min: 1, max: 10, step: 1, labels: ["Close to home", "Same country", "Anywhere in the world"] },
  },
  {
    id: "quick_15",
    category: "Dream Job",
    type: "open-ended",
    question: "If you could have any job in the world—with no barriers—what would it be?",
    subtitle: "Don't overthink this. What's the first thing that comes to mind?",
    allowSkip: true,
  },
];

export function getQuickQuestions(): QuizQuestion[] {
  return quickQuestions;
}

export function getQuickQuestionsCount(): number {
  return quickQuestions.length;
}
