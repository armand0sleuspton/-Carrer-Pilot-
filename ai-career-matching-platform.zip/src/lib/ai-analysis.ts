// AI Analysis Engine — generates comprehensive career/university matching report
// This module processes quiz responses and produces a detailed psychological,
// academic, and career profile with personalized recommendations.

export interface AIReport {
  executiveSummary: string;
  personalityProfile: {
    bigFive: {
      openness: number;
      conscientiousness: number;
      extraversion: number;
      agreeableness: number;
      neuroticism: number;
    };
    summary: string;
    strengths: string[];
    growthAreas: string[];
  };
  careerProfile: {
    topCareers: CareerMatch[];
    workStyle: string;
    leadershipStyle: string;
    innovationPotential: string;
  };
  academicProfile: {
    learningStyle: string;
    studyApproach: string;
    idealEnvironment: string;
  };
  courseMatches: CourseMatch[];
  universityMatches: UniversityMatch[];
  cityMatches: CityMatch[];
  hiddenTalents: string[];
  blindSpots: string[];
  actionPlan: string[];
  confidenceLevel: number;
}

export interface CareerMatch {
  title: string;
  field: string;
  compatibility: number;
  reasoning: string;
  dailyLife: string;
  growthPotential: string;
  salaryRange: string;
}

export interface CourseMatch {
  name: string;
  field: string;
  compatibility: number;
  reasoning: string;
  keySkills: string[];
  careerPaths: string[];
}

export interface UniversityMatch {
  name: string;
  country: string;
  city: string;
  compatibility: number;
  reasoning: string;
  strengths: string[];
  culture: string;
}

export interface CityMatch {
  name: string;
  country: string;
  compatibility: number;
  reasoning: string;
  highlights: string[];
  lifestyle: string;
}

type Responses = Record<string, string | string[] | number>;

function inferBigFive(responses: Responses) {
  const get = (id: string): number => {
    const v = responses[id];
    if (typeof v === "string") return parseInt(v, 10) || 3;
    if (typeof v === "number") return v;
    return 3;
  };
  return {
    extraversion: Math.min(100, Math.max(0, ((get("q2") + (responses["q47"] === "mingle" ? 5 : responses["q47"] === "observe" ? 3 : responses["q47"] === "leave" ? 1 : 2)) / 2) * 20)),
    openness: Math.min(100, Math.max(0, ((get("q5") + get("q22") + (get("q13") > 5 ? 4 : 2)) / 3) * 20)),
    conscientiousness: Math.min(100, Math.max(0, get("q8") * 20)),
    agreeableness: Math.min(100, Math.max(0, ((get("q11") + get("q25")) / 2) * 20)),
    neuroticism: Math.min(100, Math.max(0, get("q14") * 20)),
  };
}

function inferCareerInterests(responses: Responses): string[] {
  const interests: string[] = [];
  const q3 = responses["q3"];
  if (Array.isArray(q3)) {
    interests.push(...q3);
  }
  return interests;
}

function generateCareers(responses: Responses, bigFive: ReturnType<typeof inferBigFive>): CareerMatch[] {
  const interests = inferCareerInterests(responses);
  const creativity = bigFive.openness > 60;
  const social = bigFive.extraversion > 60;
  const analytical = interests.includes("analyze_data") || interests.includes("research");
  const helping = interests.includes("help_people");
  const building = interests.includes("build_things");
  const entrepreneurial = typeof responses["q24"] === "number" && responses["q24"] > 6;

  const careers: CareerMatch[] = [];

  if (building || analytical) {
    careers.push({
      title: "Software Engineer",
      field: "Technology",
      compatibility: 70 + (building ? 10 : 0) + (analytical ? 8 : 0) + (bigFive.conscientiousness > 60 ? 5 : 0),
      reasoning: "Your analytical thinking, love of building, and problem-solving orientation make you a natural fit for software engineering. You enjoy deep focus and creating tangible outcomes.",
      dailyLife: "Designing systems, writing code, collaborating with teams, solving complex technical challenges.",
      growthPotential: "Exceptional—tech continues to grow across all industries with strong advancement paths.",
      salaryRange: "$75,000 – $200,000+",
    });
  }

  if (creativity || interests.includes("design_things")) {
    careers.push({
      title: "UX/UI Designer",
      field: "Design & Technology",
      compatibility: 65 + (creativity ? 12 : 0) + (social ? 5 : 0) + (interests.includes("design_things") ? 10 : 0),
      reasoning: "Your creative instincts combined with empathy for users suggest you'd excel at designing intuitive, beautiful digital experiences.",
      dailyLife: "User research, wireframing, prototyping, visual design, collaborating with developers.",
      growthPotential: "Strong—design thinking is increasingly valued across all industries.",
      salaryRange: "$65,000 – $160,000+",
    });
  }

  if (helping || social) {
    careers.push({
      title: "Clinical Psychologist",
      field: "Healthcare & Psychology",
      compatibility: 60 + (helping ? 15 : 0) + (bigFive.agreeableness > 60 ? 8 : 0) + (bigFive.openness > 60 ? 5 : 0),
      reasoning: "Your deep empathy, interest in human behavior, and desire to help others suggest a fulfilling career in psychology.",
      dailyLife: "Client sessions, assessments, treatment planning, research, continuing education.",
      growthPotential: "Growing demand for mental health professionals across all demographics.",
      salaryRange: "$60,000 – $130,000+",
    });
  }

  if (entrepreneurial) {
    careers.push({
      title: "Startup Founder",
      field: "Entrepreneurship",
      compatibility: 55 + (entrepreneurial ? 20 : 0) + (bigFive.openness > 70 ? 8 : 0) + (creativity ? 5 : 0),
      reasoning: "Your entrepreneurial drive, risk tolerance, and innovative thinking position you well for building your own ventures.",
      dailyLife: "Strategy, fundraising, team building, product development, customer discovery.",
      growthPotential: "Unlimited potential but high risk—requires resilience and adaptability.",
      salaryRange: "Variable—$0 to millions",
    });
  }

  if (analytical || interests.includes("research")) {
    careers.push({
      title: "Data Scientist",
      field: "Technology & Analytics",
      compatibility: 65 + (analytical ? 12 : 0) + (bigFive.conscientiousness > 60 ? 5 : 0),
      reasoning: "Your analytical mind and research orientation are perfectly suited for extracting insights from complex datasets.",
      dailyLife: "Data analysis, machine learning models, visualization, presenting findings to stakeholders.",
      growthPotential: "Excellent—one of the fastest-growing fields globally.",
      salaryRange: "$80,000 – $180,000+",
    });
  }

  if (interests.includes("write") || interests.includes("debate")) {
    careers.push({
      title: "Content Strategist",
      field: "Marketing & Communications",
      compatibility: 62 + (interests.includes("write") ? 12 : 0) + (creativity ? 8 : 0),
      reasoning: "Your communication skills and creative thinking align well with content strategy and digital marketing.",
      dailyLife: "Content planning, writing, analytics, brand storytelling, team collaboration.",
      growthPotential: "Strong—content marketing continues to expand across industries.",
      salaryRange: "$55,000 – $120,000+",
    });
  }

  // Always add at least 3 careers
  if (careers.length < 3) {
    careers.push({
      title: "Management Consultant",
      field: "Business & Consulting",
      compatibility: 68,
      reasoning: "Your combination of analytical and interpersonal skills makes consulting a strong fit—it offers variety, challenge, and rapid learning.",
      dailyLife: "Client meetings, data analysis, strategic recommendations, presentations, travel.",
      growthPotential: "Excellent—a springboard to leadership roles across industries.",
      salaryRange: "$70,000 – $200,000+",
    });
  }
  if (careers.length < 3) {
    careers.push({
      title: "Product Manager",
      field: "Technology & Business",
      compatibility: 72,
      reasoning: "Your blend of strategic thinking and empathy positions you well to lead product development.",
      dailyLife: "User research, roadmap planning, cross-functional collaboration, data-driven decisions.",
      growthPotential: "Excellent—PM roles are expanding as more companies become tech-driven.",
      salaryRange: "$80,000 – $190,000+",
    });
  }

  return careers.sort((a, b) => b.compatibility - a.compatibility).slice(0, 5);
}

function generateCourses(careers: CareerMatch[], responses: Responses): CourseMatch[] {
  const courseMap: Record<string, CourseMatch> = {
    Technology: {
      name: "Computer Science",
      field: "STEM",
      compatibility: 0,
      reasoning: "Combines theoretical foundations with practical skills in programming, algorithms, and systems design.",
      keySkills: ["Programming", "Algorithms", "System Design", "Problem Solving"],
      careerPaths: ["Software Engineer", "Data Scientist", "AI Researcher", "CTO"],
    },
    "Design & Technology": {
      name: "Interaction Design",
      field: "Design",
      compatibility: 0,
      reasoning: "Balances creative design principles with user-centered research and digital prototyping.",
      keySkills: ["Visual Design", "User Research", "Prototyping", "Design Thinking"],
      careerPaths: ["UX Designer", "Product Designer", "Creative Director"],
    },
    "Healthcare & Psychology": {
      name: "Psychology",
      field: "Social Sciences",
      compatibility: 0,
      reasoning: "Deep exploration of human behavior, cognition, and mental health with research methodology.",
      keySkills: ["Research Methods", "Clinical Assessment", "Empathy", "Critical Analysis"],
      careerPaths: ["Psychologist", "Therapist", "HR Specialist", "Researcher"],
    },
    Entrepreneurship: {
      name: "Business Administration",
      field: "Business",
      compatibility: 0,
      reasoning: "Broad foundation in management, finance, marketing, and strategy to launch and grow ventures.",
      keySkills: ["Leadership", "Financial Analysis", "Marketing", "Strategy"],
      careerPaths: ["Entrepreneur", "CEO", "Consultant", "Product Manager"],
    },
    "Technology & Analytics": {
      name: "Data Science & Analytics",
      field: "STEM",
      compatibility: 0,
      reasoning: "Focuses on statistics, machine learning, and data-driven decision making.",
      keySkills: ["Statistics", "Machine Learning", "Python/R", "Data Visualization"],
      careerPaths: ["Data Scientist", "ML Engineer", "Analyst", "Research Scientist"],
    },
    "Marketing & Communications": {
      name: "Communications & Media",
      field: "Humanities",
      compatibility: 0,
      reasoning: "Develops writing, storytelling, and strategic communication skills for the digital age.",
      keySkills: ["Writing", "Digital Marketing", "Storytelling", "Analytics"],
      careerPaths: ["Content Strategist", "Marketing Manager", "Journalist", "PR Director"],
    },
    "Business & Consulting": {
      name: "Economics",
      field: "Social Sciences",
      compatibility: 0,
      reasoning: "Analytical framework for understanding markets, policy, and strategic decision-making.",
      keySkills: ["Quantitative Analysis", "Economic Modeling", "Critical Thinking", "Communication"],
      careerPaths: ["Consultant", "Economist", "Financial Analyst", "Policy Advisor"],
    },
    "Technology & Business": {
      name: "Information Systems",
      field: "Business & Tech",
      compatibility: 0,
      reasoning: "Bridges technology and business, ideal for product management and tech leadership.",
      keySkills: ["Systems Thinking", "Project Management", "Technical Literacy", "Strategy"],
      careerPaths: ["Product Manager", "IT Director", "Business Analyst", "Tech Consultant"],
    },
  };

  const courses: CourseMatch[] = [];
  const seen = new Set<string>();
  for (const career of careers) {
    const course = courseMap[career.field];
    if (course && !seen.has(course.name)) {
      seen.add(course.name);
      courses.push({ ...course, compatibility: Math.max(60, career.compatibility - 5) });
    }
  }

  // Add some general-interest courses
  const subjects = responses["q26"];
  if (Array.isArray(subjects)) {
    if (subjects.includes("biology") && !seen.has("Biomedical Sciences")) {
      courses.push({
        name: "Biomedical Sciences",
        field: "STEM",
        compatibility: 72,
        reasoning: "Your interest in biology aligns with cutting-edge biomedical research and healthcare innovation.",
        keySkills: ["Laboratory Skills", "Research", "Critical Analysis", "Biology"],
        careerPaths: ["Biomedical Researcher", "Physician", "Biotech Entrepreneur"],
      });
    }
    if (subjects.includes("art") && !seen.has("Fine Arts")) {
      courses.push({
        name: "Fine Arts & Visual Communication",
        field: "Arts",
        compatibility: 68,
        reasoning: "Your artistic interests could flourish in a structured fine arts program.",
        keySkills: ["Visual Communication", "Creative Thinking", "Portfolio Development"],
        careerPaths: ["Artist", "Illustrator", "Art Director", "Gallery Curator"],
      });
    }
  }

  return courses.sort((a, b) => b.compatibility - a.compatibility).slice(0, 5);
}

function generateUniversities(responses: Responses, courses: CourseMatch[]): UniversityMatch[] {
  const international = typeof responses["q34"] === "string" ? parseInt(responses["q34"], 10) : 3;
  const distance = typeof responses["q36"] === "number" ? responses["q36"] : 5;
  const financial = responses["q35"];
  const campusLife = responses["q31"];

  const universities: UniversityMatch[] = [
    {
      name: "ETH Zurich",
      country: "Switzerland",
      city: "Zurich",
      compatibility: 82,
      reasoning: "World-class STEM education in a safe, innovative city with strong industry connections.",
      strengths: ["Research Excellence", "Industry Partnerships", "Innovation Ecosystem", "Quality of Life"],
      culture: "Rigorous, international, and innovation-focused with a collaborative student community.",
    },
    {
      name: "University of Amsterdam",
      country: "Netherlands",
      city: "Amsterdam",
      compatibility: 79,
      reasoning: "Progressive teaching methods, diverse student body, and vibrant city life make this ideal for well-rounded students.",
      strengths: ["Problem-Based Learning", "International Community", "City Integration", "Liberal Culture"],
      culture: "Open-minded, diverse, and socially active with strong emphasis on independent thinking.",
    },
    {
      name: "University of Melbourne",
      country: "Australia",
      city: "Melbourne",
      compatibility: 77,
      reasoning: "Outstanding quality of life, multicultural environment, and strong academic reputation across disciplines.",
      strengths: ["Quality of Life", "Multicultural", "Research Opportunities", "Career Services"],
      culture: "Laid-back yet ambitious, with a thriving arts scene and strong community spirit.",
    },
    {
      name: "University of Toronto",
      country: "Canada",
      city: "Toronto",
      compatibility: 75,
      reasoning: "Top research university in one of the world's most diverse and livable cities.",
      strengths: ["Research Excellence", "Diversity", "Co-op Programs", "City Opportunities"],
      culture: "Diverse, intellectually stimulating, and career-oriented with many student organizations.",
    },
    {
      name: "Technical University of Munich",
      country: "Germany",
      city: "Munich",
      compatibility: 74,
      reasoning: "Excellent technical education with low tuition fees and strong industry connections.",
      strengths: ["Engineering Excellence", "Industry Connections", "Affordable", "Innovation Hub"],
      culture: "Structured, high-quality education with an entrepreneurial and international atmosphere.",
    },
  ];

  // Adjust compatibility based on preferences
  for (const uni of universities) {
    if (international > 3 && distance > 5) uni.compatibility += 3;
    if (financial === "scholarship_needed" && (uni.country === "Germany" || uni.country === "Netherlands")) uni.compatibility += 5;
    if (campusLife === "vibrant_social" && uni.city === "Amsterdam") uni.compatibility += 4;
    if (campusLife === "academic_focused" && uni.name.includes("ETH")) uni.compatibility += 4;
    uni.compatibility = Math.min(95, uni.compatibility);
  }

  return universities.sort((a, b) => b.compatibility - a.compatibility).slice(0, 5);
}

function generateCities(responses: Responses): CityMatch[] {
  const cityPrefs = responses["q32"];
  const climate = responses["q33"];
  const nightlife = typeof responses["q40"] === "number" ? responses["q40"] : 5;
  const safety = typeof responses["q54"] === "number" ? responses["q54"] : 5;
  const costImportance = typeof responses["q52"] === "number" ? responses["q52"] : 5;

  const cities: CityMatch[] = [
    {
      name: "Amsterdam",
      country: "Netherlands",
      compatibility: 80,
      reasoning: "A perfect blend of culture, safety, cycling infrastructure, and international community.",
      highlights: ["Cycling Culture", "Arts & Museums", "International", "Compact & Walkable"],
      lifestyle: "Relaxed yet dynamic, with a strong emphasis on work-life balance and sustainability.",
    },
    {
      name: "Melbourne",
      country: "Australia",
      compatibility: 78,
      reasoning: "Exceptional quality of life, multicultural food scene, and creative arts community.",
      highlights: ["Coffee Culture", "Street Art", "Beaches", "Sports"],
      lifestyle: "Laid-back with a thriving creative scene and outdoor lifestyle.",
    },
    {
      name: "Zurich",
      country: "Switzerland",
      compatibility: 76,
      reasoning: "One of the safest, cleanest, and most prosperous cities with stunning natural surroundings.",
      highlights: ["Safety", "Nature Access", "Innovation Hub", "Public Transport"],
      lifestyle: "High quality of life with excellent infrastructure and proximity to mountains and lakes.",
    },
    {
      name: "Toronto",
      country: "Canada",
      compatibility: 74,
      reasoning: "Vibrant, diverse, and filled with career opportunities across many industries.",
      highlights: ["Diversity", "Job Market", "Food Scene", "Cultural Events"],
      lifestyle: "Fast-paced and ambitious with a welcoming multicultural community.",
    },
    {
      name: "Munich",
      country: "Germany",
      compatibility: 72,
      reasoning: "A city that combines high-tech industry with traditional culture and easy access to the Alps.",
      highlights: ["Tech Industry", "Low Tuition", "Bavarian Culture", "Nature"],
      lifestyle: "Structured and efficient with excellent public services and a strong sense of community.",
    },
  ];

  for (const city of cities) {
    if (Array.isArray(cityPrefs)) {
      if (cityPrefs.includes("safety") && (city.name === "Zurich" || city.name === "Munich")) city.compatibility += 4;
      if (cityPrefs.includes("nightlife") && city.name === "Amsterdam") city.compatibility += 4;
      if (cityPrefs.includes("nature") && (city.name === "Zurich" || city.name === "Melbourne")) city.compatibility += 3;
      if (cityPrefs.includes("affordable") && city.name === "Munich") city.compatibility += 3;
      if (cityPrefs.includes("diversity") && (city.name === "Toronto" || city.name === "Amsterdam")) city.compatibility += 3;
    }
    if (climate === "warm_sunny" && city.name === "Melbourne") city.compatibility += 4;
    if (nightlife > 7 && city.name === "Amsterdam") city.compatibility += 3;
    if (safety > 7 && city.name === "Zurich") city.compatibility += 3;
    city.compatibility = Math.min(95, city.compatibility);
  }

  return cities.sort((a, b) => b.compatibility - a.compatibility).slice(0, 5);
}

export function generateAIReport(responses: Responses): AIReport {
  const bigFive = inferBigFive(responses);
  const careers = generateCareers(responses, bigFive);
  const courses = generateCourses(careers, responses);
  const universities = generateUniversities(responses, courses);
  const cities = generateCities(responses);

  const strengths: string[] = [];
  const growthAreas: string[] = [];

  if (bigFive.openness > 60) strengths.push("Creative and open to new experiences");
  else growthAreas.push("Exploring new perspectives and unconventional approaches");

  if (bigFive.conscientiousness > 60) strengths.push("Organized, disciplined, and reliable");
  else growthAreas.push("Building consistent routines and organizational habits");

  if (bigFive.extraversion > 60) strengths.push("Socially confident and energizing to be around");
  else strengths.push("Thoughtful, reflective, and a deep thinker");

  if (bigFive.agreeableness > 60) strengths.push("Empathetic and collaborative");
  else strengths.push("Independent-minded and willing to challenge ideas");

  if (bigFive.neuroticism < 40) strengths.push("Emotionally resilient under pressure");
  else growthAreas.push("Developing stress management techniques");

  const hiddenTalents: string[] = [];
  if (bigFive.openness > 70 && bigFive.conscientiousness > 60) hiddenTalents.push("You combine creativity with discipline—a rare and powerful combination for innovation");
  if (bigFive.agreeableness > 60 && bigFive.extraversion < 50) hiddenTalents.push("Your empathy combined with introspection makes you an exceptional listener and advisor");
  if (bigFive.openness > 60 && bigFive.extraversion > 60) hiddenTalents.push("Your social creativity makes you a natural connector and community builder");
  if (hiddenTalents.length === 0) hiddenTalents.push("Your unique combination of traits creates unexpected strengths in interdisciplinary thinking");

  const blindSpots: string[] = [];
  if (bigFive.conscientiousness > 80) blindSpots.push("Your high standards may lead to perfectionism—learn to ship 'good enough'");
  if (bigFive.agreeableness > 80) blindSpots.push("You may avoid necessary conflict—practice assertive communication");
  if (bigFive.neuroticism > 70) blindSpots.push("Anxiety may cause you to overthink decisions—trust your preparation");
  if (blindSpots.length === 0) blindSpots.push("You may underestimate how much your environment affects your performance—choose your surroundings carefully");

  const learningStyle = responses["q7"] === "try" || responses["q7"] === "experiment"
    ? "Kinesthetic & Experiential"
    : responses["q7"] === "read" || responses["q7"] === "structure"
    ? "Visual & Structured"
    : responses["q7"] === "discuss"
    ? "Social & Collaborative"
    : "Multimodal";

  const studyApproach = responses["q28"] === "consistent"
    ? "Methodical and consistent—you build knowledge steadily over time."
    : responses["q28"] === "cramming"
    ? "Intensity-driven—you perform under pressure, but consider spacing out your learning for deeper retention."
    : responses["q28"] === "deep_focus"
    ? "Deep focus—you excel when fully immersed, creating long periods of uninterrupted concentration."
    : "Adaptive—you adjust your approach based on the situation.";

  return {
    executiveSummary: `Based on your responses, you are a ${bigFive.openness > 60 ? "creative" : "practical"} and ${bigFive.extraversion > 60 ? "socially energized" : "introspective"} individual who values ${bigFive.agreeableness > 60 ? "collaboration and empathy" : "independence and direct communication"}. Your strongest career matches are in ${careers[0]?.field || "multiple fields"}, with ${careers[0]?.title || "several promising careers"} emerging as your top fit. You would thrive in a ${bigFive.openness > 60 ? "dynamic, innovative" : "structured, focused"} academic environment.`,
    personalityProfile: {
      bigFive,
      summary: `Your personality profile reveals a ${bigFive.extraversion > 60 ? "socially confident" : "thoughtful and reflective"} individual with ${bigFive.openness > 60 ? "strong creative instincts" : "a practical, grounded approach"} and ${bigFive.conscientiousness > 60 ? "excellent organizational skills" : "a flexible, adaptive work style"}.`,
      strengths,
      growthAreas: growthAreas.length > 0 ? growthAreas : ["Continue developing your already strong interpersonal skills"],
    },
    careerProfile: {
      topCareers: careers,
      workStyle: responses["q10"] === "home_alone" ? "Independent & Remote" : responses["q10"] === "co_working" ? "Collaborative & Flexible" : "Structured & Team-oriented",
      leadershipStyle: responses["q15"] === "lead" ? "Directive & Organized" : responses["q15"] === "ideas" ? "Visionary & Creative" : responses["q15"] === "mediate" ? "Servant & Empathetic" : "Supportive & Collaborative",
      innovationPotential: bigFive.openness > 70 ? "High—you naturally seek novel solutions and challenge conventions" : "Moderate—you balance innovation with proven approaches",
    },
    academicProfile: {
      learningStyle,
      studyApproach,
      idealEnvironment: responses["q27"] === "hands_on" ? "A program with strong practical components, labs, and project-based learning" : responses["q27"] === "discussion" ? "A discussion-rich environment with seminars and collaborative projects" : "A structured program with clear progression and mentorship opportunities",
    },
    courseMatches: courses,
    universityMatches: universities,
    cityMatches: cities,
    hiddenTalents,
    blindSpots,
    actionPlan: [
      `Research your top course: ${courses[0]?.name || "Computer Science"} — compare curricula across your matched universities`,
      `Visit or virtually tour your top university: ${universities[0]?.name || "ETH Zurich"}`,
      `Connect with current students through university forums and social media`,
      `Start building skills relevant to ${careers[0]?.title || "your top career"} through online courses or projects`,
      `Explore scholarship opportunities at your matched universities`,
      `Create a timeline with application deadlines and requirements`,
    ],
    confidenceLevel: Math.min(95, 60 + Object.keys(responses).length),
  };
}
