"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import Link from "next/link";
import { generateAIReport, type AIReport, type CareerMatch, type CourseMatch, type UniversityMatch, type CityMatch } from "@/lib/ai-analysis";

/* ─── Compatibility Ring ─── */
function CompatRing({ value, size = 64 }: { value: number; size?: number }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;
  const color = value >= 80 ? "#22c55e" : value >= 60 ? "#5c7cfa" : "#f59e0b";

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={4} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={4} strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={offset} style={{ transition: "stroke-dashoffset 1.5s cubic-bezier(0.4,0,0.2,1)" }} />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xs font-bold">{value}%</span>
      </div>
    </div>
  );
}

/* ─── Big Five Bar ─── */
function BigFiveBar({ label, value }: { label: string; value: number }) {
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-sm">
        <span className="text-dark-text/80 font-medium">{label}</span>
        <span className="text-dark-muted text-xs">{Math.round(value)}%</span>
      </div>
      <div className="h-2 bg-dark-border rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-1000"
          style={{
            width: `${value}%`,
            background: `linear-gradient(90deg, var(--color-brand-500), var(--color-brand-300))`,
          }}
        />
      </div>
    </div>
  );
}

/* ─── Section Wrapper ─── */
function Section({ title, icon, children }: { title: string; icon: string; children: React.ReactNode }) {
  return (
    <section className="glass-card rounded-2xl p-6 md:p-8">
      <div className="flex items-center gap-3 mb-6">
        <span className="text-2xl">{icon}</span>
        <h2 className="text-xl font-bold tracking-tight">{title}</h2>
      </div>
      {children}
    </section>
  );
}

/* ─── Tab Button ─── */
function TabBtn({ active, label, icon, onClick }: { active: boolean; label: string; icon: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap ${active ? "bg-brand-500/15 text-brand-300 border border-brand-500/25" : "text-dark-muted hover:text-white border border-transparent"}`}>
      <span>{icon}</span>{label}
    </button>
  );
}

/* ─── Career Card ─── */
function CareerCard({ career, rank }: { career: CareerMatch; rank: number }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-dark-border rounded-xl p-5 hover:border-dark-muted transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center text-brand-400 font-bold text-sm shrink-0">#{rank}</div>
          <div className="min-w-0">
            <h3 className="font-bold text-base">{career.title}</h3>
            <p className="text-dark-muted text-xs mt-0.5">{career.field}</p>
          </div>
        </div>
        <CompatRing value={career.compatibility} />
      </div>
      <p className="text-sm text-dark-text/70 mt-4 leading-relaxed">{career.reasoning}</p>
      <button onClick={() => setOpen(!open)} className="text-brand-400 text-xs font-medium mt-3 hover:text-brand-300 transition-colors">
        {open ? "Show less" : "Show more details"}
      </button>
      {open && (
        <div className="mt-4 space-y-3 text-sm">
          <div><span className="text-dark-muted">Daily Life:</span> <span className="text-dark-text/80">{career.dailyLife}</span></div>
          <div><span className="text-dark-muted">Growth:</span> <span className="text-dark-text/80">{career.growthPotential}</span></div>
          <div><span className="text-dark-muted">Salary:</span> <span className="text-dark-text/80">{career.salaryRange}</span></div>
        </div>
      )}
    </div>
  );
}

/* ─── Course Card ─── */
function CourseCard({ course, rank }: { course: CourseMatch; rank: number }) {
  return (
    <div className="border border-dark-border rounded-xl p-5 hover:border-dark-muted transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center text-brand-400 font-bold text-sm shrink-0">#{rank}</div>
          <div className="min-w-0">
            <h3 className="font-bold text-base">{course.name}</h3>
            <p className="text-dark-muted text-xs mt-0.5">{course.field}</p>
          </div>
        </div>
        <CompatRing value={course.compatibility} />
      </div>
      <p className="text-sm text-dark-text/70 mt-4 leading-relaxed">{course.reasoning}</p>
      <div className="flex flex-wrap gap-2 mt-3">
        {course.keySkills.map((s) => (
          <span key={s} className="px-2 py-0.5 rounded-md bg-dark-border text-dark-muted text-xs">{s}</span>
        ))}
      </div>
    </div>
  );
}

/* ─── University Card ─── */
function UniCard({ uni, rank }: { uni: UniversityMatch; rank: number }) {
  return (
    <div className="border border-dark-border rounded-xl p-5 hover:border-dark-muted transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center text-brand-400 font-bold text-sm shrink-0">#{rank}</div>
          <div className="min-w-0">
            <h3 className="font-bold text-base">{uni.name}</h3>
            <p className="text-dark-muted text-xs mt-0.5">{uni.city}, {uni.country}</p>
          </div>
        </div>
        <CompatRing value={uni.compatibility} />
      </div>
      <p className="text-sm text-dark-text/70 mt-4 leading-relaxed">{uni.reasoning}</p>
      <div className="flex flex-wrap gap-2 mt-3">
        {uni.strengths.map((s) => (
          <span key={s} className="px-2 py-0.5 rounded-md bg-dark-border text-dark-muted text-xs">{s}</span>
        ))}
      </div>
      <p className="text-xs text-dark-muted mt-3 italic">{uni.culture}</p>
    </div>
  );
}

/* ─── City Card ─── */
function CityCard({ city, rank }: { city: CityMatch; rank: number }) {
  return (
    <div className="border border-dark-border rounded-xl p-5 hover:border-dark-muted transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-4 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-brand-500/10 flex items-center justify-center text-brand-400 font-bold text-sm shrink-0">#{rank}</div>
          <div className="min-w-0">
            <h3 className="font-bold text-base">{city.name}</h3>
            <p className="text-dark-muted text-xs mt-0.5">{city.country}</p>
          </div>
        </div>
        <CompatRing value={city.compatibility} />
      </div>
      <p className="text-sm text-dark-text/70 mt-4 leading-relaxed">{city.reasoning}</p>
      <div className="flex flex-wrap gap-2 mt-3">
        {city.highlights.map((h) => (
          <span key={h} className="px-2 py-0.5 rounded-md bg-dark-border text-dark-muted text-xs">{h}</span>
        ))}
      </div>
    </div>
  );
}

/* ─── Loading State ─── */
function LoadingState() {
  const messages = [
    "Analyzing your personality profile...",
    "Mapping your career compatibility...",
    "Evaluating course matches...",
    "Scoring university fit...",
    "Analyzing ideal cities...",
    "Generating your personalized report...",
  ];
  const [msgIdx, setMsgIdx] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMsgIdx((i) => (i + 1) % messages.length);
    }, 800);
    return () => clearInterval(interval);
  }, [messages.length]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-bg px-6">
      <div className="text-center max-w-md">
        <div className="mb-8 relative">
          <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center animate-pulse">
            <span className="text-3xl">🧠</span>
          </div>
        </div>
        <h2 className="text-2xl font-bold mb-3">Building Your AI Report</h2>
        <p className="text-dark-muted text-sm mb-6">{messages[msgIdx]}</p>
        <div className="w-48 mx-auto h-1 bg-dark-border rounded-full overflow-hidden">
          <div className="h-full bg-brand-500 rounded-full animate-shimmer" style={{ width: "60%" }} />
        </div>
      </div>
    </div>
  );
}

/* ─── Main Results Page ─── */
export default function ResultsPage() {
  const [report, setReport] = useState<AIReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"careers" | "courses" | "universities" | "cities">("careers");
  const saved = useRef(false);

  useEffect(() => {
    const stored = localStorage.getItem("careerpilot_responses");
    const quizType = localStorage.getItem("careerpilot_quiz_type") || "deep";
    const responses = stored ? JSON.parse(stored) : {};

    // Simulate AI processing time (shorter for quick assessment)
    const processingTime = quizType === "quick" ? 2000 : 3500;
    const timer = setTimeout(() => {
      const r = generateAIReport(responses);
      setReport(r);
      setLoading(false);

      // Save to DB
      if (!saved.current) {
        saved.current = true;
        fetch("/api/quiz/submit", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ responses, report: r }),
        }).catch(() => {});
      }
    }, 3500);

    return () => clearTimeout(timer);
  }, []);

  if (loading || !report) return <LoadingState />;

  const bf = report.personalityProfile.bigFive;

  return (
    <div className="min-h-screen bg-dark-bg relative">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 bg-brand-500 rounded-full blur-3xl opacity-8 -top-48 left-1/4" />
        <div className="absolute w-80 h-80 bg-accent-500 rounded-full blur-3xl opacity-8 top-[60rem] -right-40" />
      </div>

      {/* Header */}
      <header className="glass sticky top-0 z-40" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-xs">P</div>
            <span className="font-semibold text-sm">CareerPilot</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/quiz" className="text-dark-muted hover:text-white text-sm transition-colors">Retake Quiz</Link>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8 pb-20 relative z-10 space-y-8">
        {/* ── Hero ── */}
        <div className="text-center py-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium mb-6"
            style={{ background: "rgba(34, 197, 94, 0.12)", border: "1px solid rgba(34, 197, 94, 0.2)", color: "rgb(74, 222, 128)" }}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
            Report Generated • Confidence: {report.confidenceLevel}%
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
            Your AI Career Report
          </h1>
          <p className="text-dark-muted max-w-xl mx-auto leading-relaxed">
            {report.executiveSummary}
          </p>
        </div>

        {/* ── Personality Profile ── */}
        <Section title="Personality Profile" icon="🧠">
          <p className="text-dark-text/70 text-sm leading-relaxed mb-6">{report.personalityProfile.summary}</p>

          <h3 className="text-sm font-semibold mb-4 text-dark-muted uppercase tracking-wider">Big Five Personality Traits</h3>
          <div className="space-y-4 mb-8">
            <BigFiveBar label="Openness" value={bf.openness} />
            <BigFiveBar label="Conscientiousness" value={bf.conscientiousness} />
            <BigFiveBar label="Extraversion" value={bf.extraversion} />
            <BigFiveBar label="Agreeableness" value={bf.agreeableness} />
            <BigFiveBar label="Neuroticism" value={bf.neuroticism} />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-semibold mb-3 text-green-400">✦ Strengths</h3>
              <ul className="space-y-2">
                {report.personalityProfile.strengths.map((s, i) => (
                  <li key={i} className="text-sm text-dark-text/70 flex items-start gap-2">
                    <span className="text-green-400 mt-0.5">•</span>{s}
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold mb-3 text-amber-400">✦ Growth Areas</h3>
              <ul className="space-y-2">
                {report.personalityProfile.growthAreas.map((g, i) => (
                  <li key={i} className="text-sm text-dark-text/70 flex items-start gap-2">
                    <span className="text-amber-400 mt-0.5">•</span>{g}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Section>

        {/* ── Hidden Talents & Blind Spots ── */}
        <div className="grid md:grid-cols-2 gap-6">
          <Section title="Hidden Talents" icon="💎">
            <ul className="space-y-3">
              {report.hiddenTalents.map((t, i) => (
                <li key={i} className="text-sm text-dark-text/70 leading-relaxed">{t}</li>
              ))}
            </ul>
          </Section>
          <Section title="Blind Spots" icon="🔍">
            <ul className="space-y-3">
              {report.blindSpots.map((b, i) => (
                <li key={i} className="text-sm text-dark-text/70 leading-relaxed">{b}</li>
              ))}
            </ul>
          </Section>
        </div>

        {/* ── Academic & Career Profiles ── */}
        <div className="grid md:grid-cols-3 gap-6">
          <Section title="Learning Style" icon="📖">
            <div className="text-sm space-y-3">
              <div><span className="text-dark-muted">Style:</span> <span className="text-dark-text/80 font-medium">{report.academicProfile.learningStyle}</span></div>
              <p className="text-dark-text/70 leading-relaxed">{report.academicProfile.studyApproach}</p>
              <p className="text-dark-text/70 leading-relaxed">{report.academicProfile.idealEnvironment}</p>
            </div>
          </Section>
          <Section title="Work Style" icon="💼">
            <div className="text-sm space-y-3">
              <div><span className="text-dark-muted">Work Style:</span> <span className="text-dark-text/80 font-medium">{report.careerProfile.workStyle}</span></div>
              <div><span className="text-dark-muted">Leadership:</span> <span className="text-dark-text/80 font-medium">{report.careerProfile.leadershipStyle}</span></div>
              <div><span className="text-dark-muted">Innovation:</span> <span className="text-dark-text/80 font-medium">{report.careerProfile.innovationPotential}</span></div>
            </div>
          </Section>
          <Section title="Confidence" icon="📊">
            <div className="flex flex-col items-center justify-center py-4">
              <CompatRing value={report.confidenceLevel} size={96} />
              <p className="text-dark-muted text-xs mt-3 text-center">Based on {Object.keys(JSON.parse(localStorage.getItem("careerpilot_responses") || "{}")).length} answered questions</p>
            </div>
          </Section>
        </div>

        {/* ── Recommendations Tabs ── */}
        <div>
          <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
            <TabBtn active={activeTab === "careers"} label="Careers" icon="🎯" onClick={() => setActiveTab("careers")} />
            <TabBtn active={activeTab === "courses"} label="Courses" icon="🎓" onClick={() => setActiveTab("courses")} />
            <TabBtn active={activeTab === "universities"} label="Universities" icon="🏛️" onClick={() => setActiveTab("universities")} />
            <TabBtn active={activeTab === "cities"} label="Cities" icon="🌍" onClick={() => setActiveTab("cities")} />
          </div>

          <div className="space-y-4">
            {activeTab === "careers" && report.careerProfile.topCareers.map((c, i) => (
              <CareerCard key={c.title} career={c} rank={i + 1} />
            ))}
            {activeTab === "courses" && report.courseMatches.map((c, i) => (
              <CourseCard key={c.name} course={c} rank={i + 1} />
            ))}
            {activeTab === "universities" && report.universityMatches.map((u, i) => (
              <UniCard key={u.name} uni={u} rank={i + 1} />
            ))}
            {activeTab === "cities" && report.cityMatches.map((c, i) => (
              <CityCard key={c.name} city={c} rank={i + 1} />
            ))}
          </div>
        </div>

        {/* ── Action Plan ── */}
        <Section title="Your Action Plan" icon="🚀">
          <div className="space-y-4">
            {report.actionPlan.map((step, i) => (
              <div key={i} className="flex items-start gap-4">
                <div className="w-8 h-8 rounded-lg bg-brand-500/10 flex items-center justify-center text-brand-400 font-bold text-xs shrink-0">
                  {i + 1}
                </div>
                <p className="text-sm text-dark-text/80 leading-relaxed pt-1.5">{step}</p>
              </div>
            ))}
          </div>
        </Section>

        {/* ── Bottom CTA ── */}
        <div className="text-center py-8">
          <div className="glass-card rounded-2xl p-8 md:p-12">
            <h2 className="text-2xl font-bold mb-3">Want to refine your results?</h2>
            <p className="text-dark-muted text-sm mb-6">Answer more questions for even more accurate recommendations.</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link href="/quiz" className="btn-primary text-sm !py-2.5 !px-6">
                Retake Assessment
              </Link>
              <Link href="/" className="text-dark-muted hover:text-white text-sm transition-colors px-4 py-2.5">
                Back to Home
              </Link>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
