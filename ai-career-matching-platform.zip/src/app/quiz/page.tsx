"use client";

import Link from "next/link";
import { useState } from "react";

export default function QuizSelectionPage() {
  const [hoveredCard, setHoveredCard] = useState<"quick" | "deep" | null>(null);

  return (
    <div className="min-h-screen bg-dark-bg relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute w-96 h-96 bg-brand-500 rounded-full blur-3xl opacity-10 -top-48 -left-48 animate-float" />
        <div className="absolute w-80 h-80 bg-accent-500 rounded-full blur-3xl opacity-10 -bottom-40 -right-40 animate-float" style={{ animationDelay: "3s" }} />
      </div>

      {/* Header */}
      <header className="glass sticky top-0 z-40" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-xs">C</div>
            <span className="font-semibold text-sm">CareerPilot</span>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-6 py-16 md:py-24 relative z-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium mb-6"
            style={{ background: "rgba(92, 124, 250, 0.12)", border: "1px solid rgba(92, 124, 250, 0.2)", color: "rgb(145, 167, 255)" }}>
            <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" />
            Choose Your Assessment
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
            How deep do you want to go?
          </h1>
          <p className="text-dark-muted text-lg max-w-xl mx-auto">
            Choose the assessment that fits your time. Both provide personalized AI recommendations.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {/* Quick Assessment */}
          <Link
            href="/quiz/quick"
            onMouseEnter={() => setHoveredCard("quick")}
            onMouseLeave={() => setHoveredCard(null)}
            className={`glass-card rounded-2xl p-8 text-left transition-all duration-300 group relative overflow-hidden ${
              hoveredCard === "quick" ? "scale-[1.02] shadow-2xl shadow-brand-500/10" : ""
            }`}
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-brand-500/20 to-transparent rounded-bl-full" />
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-brand-500/10 flex items-center justify-center">
                  <span className="text-3xl">⚡</span>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold gradient-text">~5 min</div>
                  <div className="text-dark-muted text-xs">15 questions</div>
                </div>
              </div>

              <h2 className="text-xl font-bold mb-2">Quick Assessment</h2>
              <p className="text-dark-muted text-sm leading-relaxed mb-6">
                Get fast, accurate recommendations when you&apos;re short on time. Perfect for exploring your options.
              </p>

              <div className="space-y-2 mb-6">
                {["Core personality traits", "Top career matches", "University recommendations", "City compatibility"].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-sm text-dark-text/70">
                    <svg className="w-4 h-4 text-brand-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                    {item}
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 text-brand-400 font-medium text-sm group-hover:gap-3 transition-all">
                Start Quick Assessment
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>
          </Link>

          {/* Deep Assessment */}
          <Link
            href="/quiz/deep"
            onMouseEnter={() => setHoveredCard("deep")}
            onMouseLeave={() => setHoveredCard(null)}
            className={`glass-card rounded-2xl p-8 text-left transition-all duration-300 group relative overflow-hidden ${
              hoveredCard === "deep" ? "scale-[1.02] shadow-2xl shadow-accent-500/10" : ""
            }`}
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-accent-500/20 to-transparent rounded-bl-full" />
            
            {/* Recommended badge */}
            <div className="absolute top-4 right-4 px-2 py-1 rounded-full text-xs font-semibold"
              style={{ background: "rgba(247, 131, 172, 0.15)", color: "rgb(247, 131, 172)" }}>
              Recommended
            </div>

            <div className="relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-accent-500/10 flex items-center justify-center">
                  <span className="text-3xl">🧠</span>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold" style={{ color: "rgb(247, 131, 172)" }}>~25 min</div>
                  <div className="text-dark-muted text-xs">55 questions</div>
                </div>
              </div>

              <h2 className="text-xl font-bold mb-2">Deep Assessment</h2>
              <p className="text-dark-muted text-sm leading-relaxed mb-6">
                Comprehensive psychological profiling for the most accurate, personalized recommendations.
              </p>

              <div className="space-y-2 mb-6">
                {[
                  "Full Big Five personality analysis",
                  "Hidden talents & blind spots",
                  "Detailed career reasoning",
                  "Learning style & work preferences",
                  "Personalized action plan",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-sm text-dark-text/70">
                    <svg className="w-4 h-4 text-accent-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                    {item}
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 font-medium text-sm group-hover:gap-3 transition-all" style={{ color: "rgb(247, 131, 172)" }}>
                Start Deep Assessment
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>
          </Link>
        </div>

        {/* Bottom note */}
        <p className="text-center text-dark-muted text-sm mt-12">
          Not sure? Start with Quick—you can always take the Deep Assessment later.
        </p>
      </main>
    </div>
  );
}
