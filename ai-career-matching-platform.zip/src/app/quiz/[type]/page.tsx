"use client";

import { useState, useCallback, useMemo, useEffect, use } from "react";
import { useRouter } from "next/navigation";
import { getQuestions, type QuizQuestion } from "@/lib/quiz-data";
import { getQuickQuestions } from "@/lib/quiz-questions-quick";

type Responses = Record<string, string | string[] | number>;

/* ─── Progress Bar ─── */
function ProgressBar({ current, total }: { current: number; total: number }) {
  const pct = Math.round((current / total) * 100);
  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-dark-muted font-medium">Question {current + 1} of {total}</span>
        <span className="text-xs font-semibold gradient-text">{pct}%</span>
      </div>
      <div className="h-1.5 bg-dark-border rounded-full overflow-hidden">
        <div className="progress-bar h-full rounded-full" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

/* ─── Category Badge ─── */
function CategoryBadge({ category }: { category: string }) {
  return (
    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium"
      style={{ background: "rgba(92, 124, 250, 0.12)", border: "1px solid rgba(92, 124, 250, 0.2)", color: "rgb(145, 167, 255)" }}>
      {category}
    </span>
  );
}

/* ─── Single Choice ─── */
function SingleChoice({ question, value, onChange }: {
  question: QuizQuestion;
  value: string | undefined;
  onChange: (val: string) => void;
}) {
  return (
    <div className="grid gap-3">
      {question.options?.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`w-full text-left p-4 rounded-xl border transition-all duration-200 flex items-center gap-3 group ${
            value === opt.value
              ? "border-brand-500 bg-brand-500/10 shadow-lg shadow-brand-500/10"
              : "border-dark-border bg-dark-card hover:border-dark-muted hover:bg-dark-card/80"
          }`}
        >
          <span className="text-xl shrink-0">{opt.emoji}</span>
          <span className={`text-sm font-medium ${value === opt.value ? "text-white" : "text-dark-text/80"}`}>
            {opt.label}
          </span>
          {value === opt.value && (
            <svg className="w-5 h-5 text-brand-400 ml-auto shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          )}
        </button>
      ))}
    </div>
  );
}

/* ─── Multiple Choice ─── */
function MultipleChoice({ question, value, onChange }: {
  question: QuizQuestion;
  value: string[] | undefined;
  onChange: (val: string[]) => void;
}) {
  const selected = value || [];
  const toggle = (v: string) => {
    onChange(selected.includes(v) ? selected.filter((s) => s !== v) : [...selected, v]);
  };

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {question.options?.map((opt) => {
        const isSelected = selected.includes(opt.value);
        return (
          <button
            key={opt.value}
            onClick={() => toggle(opt.value)}
            className={`text-left p-4 rounded-xl border transition-all duration-200 flex items-center gap-3 ${
              isSelected
                ? "border-brand-500 bg-brand-500/10 shadow-lg shadow-brand-500/10"
                : "border-dark-border bg-dark-card hover:border-dark-muted"
            }`}
          >
            <span className="text-xl shrink-0">{opt.emoji}</span>
            <span className={`text-sm font-medium ${isSelected ? "text-white" : "text-dark-text/80"}`}>
              {opt.label}
            </span>
            {isSelected && (
              <svg className="w-5 h-5 text-brand-400 ml-auto shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ─── Likert Scale ─── */
function LikertScale({ question, value, onChange }: {
  question: QuizQuestion;
  value: string | undefined;
  onChange: (val: string) => void;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:gap-2 justify-center">
      {question.options?.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`flex-1 p-4 rounded-xl border text-center transition-all duration-200 ${
            value === opt.value
              ? "border-brand-500 bg-brand-500/10 shadow-lg shadow-brand-500/10"
              : "border-dark-border bg-dark-card hover:border-dark-muted"
          }`}
        >
          <span className={`text-sm font-medium ${value === opt.value ? "text-white" : "text-dark-text/80"}`}>
            {opt.label}
          </span>
        </button>
      ))}
    </div>
  );
}

/* ─── Slider ─── */
function SliderInput({ question, value, onChange }: {
  question: QuizQuestion;
  value: number | undefined;
  onChange: (val: number) => void;
}) {
  const config = question.sliderConfig!;
  const current = value ?? Math.round((config.min + config.max) / 2);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="text-5xl font-extrabold gradient-text">{current}</div>
        <div className="text-dark-muted text-sm mt-1">
          {config.labels?.[current <= 3 ? 0 : current <= 7 ? 1 : 2] || ""}
        </div>
      </div>
      <input
        type="range"
        min={config.min}
        max={config.max}
        step={config.step}
        value={current}
        onChange={(e) => onChange(parseInt(e.target.value, 10))}
        className="w-full h-2 rounded-lg appearance-none cursor-pointer accent-brand-500"
        style={{
          background: `linear-gradient(to right, var(--color-brand-500) 0%, var(--color-brand-500) ${((current - config.min) / (config.max - config.min)) * 100}%, var(--color-dark-border) ${((current - config.min) / (config.max - config.min)) * 100}%, var(--color-dark-border) 100%)`,
        }}
      />
      <div className="flex justify-between text-xs text-dark-muted">
        <span>{config.labels?.[0] || config.min}</span>
        <span>{config.labels?.[2] || config.max}</span>
      </div>
    </div>
  );
}

/* ─── Open Ended ─── */
function OpenEnded({ value, onChange }: {
  value: string | undefined;
  onChange: (val: string) => void;
}) {
  return (
    <textarea
      value={value || ""}
      onChange={(e) => onChange(e.target.value)}
      placeholder="Type your answer here..."
      className="w-full h-32 p-4 rounded-xl border border-dark-border bg-dark-card text-dark-text text-sm resize-none focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500/30 transition-all"
    />
  );
}

/* ─── Insight Messages ─── */
const insights = [
  "Your responses are painting a unique picture...",
  "Interesting pattern emerging—your creativity and analytical thinking are both strong.",
  "We're building a multi-dimensional profile of your strengths.",
  "Your values are becoming clearer with each answer.",
  "Almost there—these deeper questions help us understand what truly drives you.",
  "Your personality profile is taking shape beautifully.",
  "We're analyzing how you'd thrive in different environments.",
  "Your ideal career path is becoming clearer.",
];

/* ─── Main Quiz Page ─── */
export default function QuizPage({ params }: { params: Promise<{ type: string }> }) {
  const { type } = use(params);
  const router = useRouter();
  
  const questions = useMemo(() => {
    return type === "quick" ? getQuickQuestions() : getQuestions();
  }, [type]);
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [responses, setResponses] = useState<Responses>({});
  const [animating, setAnimating] = useState(false);
  const [direction, setDirection] = useState<"next" | "prev">("next");

  const question = questions[currentIndex];
  const isFirst = currentIndex === 0;
  const isLast = currentIndex === questions.length - 1;

  const currentValue = responses[question.id];

  const hasAnswer = (() => {
    if (currentValue === undefined || currentValue === null) return false;
    if (Array.isArray(currentValue)) return currentValue.length > 0;
    if (typeof currentValue === "string") return currentValue.trim().length > 0;
    return true;
  })();

  const setAnswer = useCallback(
    (val: string | string[] | number) => {
      setResponses((prev) => ({ ...prev, [question.id]: val }));
    },
    [question.id]
  );

  const goNext = useCallback(() => {
    if (isLast) {
      // Save to localStorage and redirect
      localStorage.setItem("careerpilot_responses", JSON.stringify(responses));
      localStorage.setItem("careerpilot_quiz_type", type);
      router.push("/results");
      return;
    }
    setDirection("next");
    setAnimating(true);
    setTimeout(() => {
      setCurrentIndex((i) => i + 1);
      setAnimating(false);
    }, 200);
  }, [isLast, responses, router, type]);

  const goPrev = useCallback(() => {
    if (isFirst) return;
    setDirection("prev");
    setAnimating(true);
    setTimeout(() => {
      setCurrentIndex((i) => i - 1);
      setAnimating(false);
    }, 200);
  }, [isFirst]);

  const skip = useCallback(() => {
    setResponses((prev) => ({ ...prev, [question.id]: "skipped" }));
    goNext();
  }, [question.id, goNext]);

  // Show insight every 8 questions (only for deep assessment)
  const showInsight = type === "deep" && currentIndex > 0 && currentIndex % 8 === 0;
  const insightMsg = insights[Math.floor(currentIndex / 8) % insights.length];

  // Keyboard navigation
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Enter" && hasAnswer) goNext();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [hasAnswer, goNext]);

  const quizLabel = type === "quick" ? "Quick Assessment" : "Deep Assessment";

  return (
    <div className="min-h-screen flex flex-col bg-dark-bg relative">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 bg-brand-500 rounded-full blur-3xl opacity-10 -top-48 -left-48 animate-float" />
        <div className="absolute w-80 h-80 bg-accent-500 rounded-full blur-3xl opacity-10 -bottom-40 -right-40 animate-float" style={{ animationDelay: "3s" }} />
      </div>

      {/* Header */}
      <header className="glass sticky top-0 z-40 border-b border-dark-border/50">
        <div className="max-w-3xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-3">
            <button onClick={() => router.push("/quiz")} className="flex items-center gap-2 text-dark-muted hover:text-white transition-colors text-sm">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
              Exit
            </button>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-xs">C</div>
              <span className="font-semibold text-sm">CareerPilot</span>
              <span className="text-dark-muted text-xs">• {quizLabel}</span>
            </div>
          </div>
          <ProgressBar current={currentIndex} total={questions.length} />
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 flex items-center justify-center px-6 py-8">
        <div className={`w-full max-w-2xl transition-all duration-200 ${animating ? (direction === "next" ? "opacity-0 translate-x-8" : "opacity-0 -translate-x-8") : "opacity-100 translate-x-0"}`}>
          {/* Insight */}
          {showInsight && (
            <div className="mb-8 p-4 rounded-xl bg-brand-500/8 border border-brand-500/15 flex items-start gap-3">
              <span className="text-brand-400 text-lg mt-0.5">✨</span>
              <div>
                <p className="text-sm text-brand-300 font-medium">{insightMsg}</p>
              </div>
            </div>
          )}

          {/* Category */}
          <div className="mb-4">
            <CategoryBadge category={question.category} />
          </div>

          {/* Question */}
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-2 leading-snug">
            {question.question}
          </h2>
          {question.subtitle && (
            <p className="text-dark-muted text-sm mb-8">{question.subtitle}</p>
          )}
          {!question.subtitle && <div className="mb-8" />}

          {/* Answer */}
          <div className="mb-8">
            {(question.type === "single" || question.type === "scenario" || question.type === "image-preference") && (
              <SingleChoice
                question={question}
                value={currentValue as string | undefined}
                onChange={setAnswer}
              />
            )}
            {question.type === "multiple" && (
              <MultipleChoice
                question={question}
                value={currentValue as string[] | undefined}
                onChange={setAnswer}
              />
            )}
            {question.type === "multiple-top3" && (
              <MultipleChoice
                question={question}
                value={currentValue as string[] | undefined}
                onChange={setAnswer}
              />
            )}
            {question.type === "likert" && (
              <LikertScale
                question={question}
                value={currentValue as string | undefined}
                onChange={setAnswer}
              />
            )}
            {question.type === "slider" && (
              <SliderInput
                question={question}
                value={currentValue as number | undefined}
                onChange={setAnswer}
              />
            )}
            {question.type === "open-ended" && (
              <OpenEnded
                value={currentValue as string | undefined}
                onChange={setAnswer}
              />
            )}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <button
              onClick={goPrev}
              disabled={isFirst}
              className={`flex items-center gap-2 text-sm font-medium transition-colors ${isFirst ? "text-dark-border cursor-not-allowed" : "text-dark-muted hover:text-white"}`}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
              Back
            </button>

            <div className="flex items-center gap-3">
              {(question.allowSkip || question.allowUnsure) && (
                <button onClick={skip} className="text-dark-muted hover:text-white text-sm transition-colors">
                  Skip
                </button>
              )}
              <button
                onClick={goNext}
                disabled={!hasAnswer && question.type !== "slider"}
                className={`flex items-center gap-2 text-sm font-semibold px-6 py-2.5 rounded-xl transition-all duration-200 ${
                  hasAnswer || question.type === "slider"
                    ? "btn-primary !py-2.5 !px-6"
                    : "bg-dark-border text-dark-muted cursor-not-allowed"
                }`}
              >
                {isLast ? "See My Results" : "Continue"}
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
