"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";

/* ─── Animated Counter ─── */
function Counter({ end, suffix = "", duration = 2000 }: { end: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const startTime = performance.now();
          const animate = (now: number) => {
            const progress = Math.min((now - startTime) / duration, 1);
            setCount(Math.floor(progress * end));
            if (progress < 1) requestAnimationFrame(animate);
          };
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [end, duration]);

  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>;
}

/* ─── Star Rating ─── */
function Stars({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }, (_, i) => (
        <svg key={i} className={`w-4 h-4 ${i < count ? "text-yellow-400" : "text-dark-border"}`} fill="currentColor" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

/* ─── Floating Orb ─── */
function FloatingOrb({ className, style }: { className: string; style?: React.CSSProperties }) {
  return <div className={`absolute rounded-full blur-3xl opacity-20 ${className}`} style={style} />;
}

export default function LandingPage() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const features = [
    {
      icon: "🧠",
      title: "Psychological Profiling",
      description: "Deep personality analysis using Big Five, motivations, values, and cognitive patterns.",
    },
    {
      icon: "🎯",
      title: "Career Matching",
      description: "AI-powered career recommendations based on who you are, not just what you study.",
    },
    {
      icon: "🎓",
      title: "Course Compatibility",
      description: "Multi-dimensional course matching that goes beyond keywords and rankings.",
    },
    {
      icon: "🏛️",
      title: "University Fit",
      description: "Find universities where you'll thrive—academically, socially, and emotionally.",
    },
    {
      icon: "🌍",
      title: "City Analysis",
      description: "Discover cities that match your lifestyle, values, and quality-of-life priorities.",
    },
    {
      icon: "📊",
      title: "AI Report",
      description: "Receive a comprehensive report that feels like a premium career consultation.",
    },
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Now studying CS at ETH Zurich",
      quote: "CareerPilot didn't just recommend a university—it understood who I am. I'm thriving here.",
      stars: 5,
    },
    {
      name: "Marcus Rivera",
      role: "Psychology student, UvA Amsterdam",
      quote: "I was torn between five different paths. CareerPilot helped me see what I couldn't see myself.",
      stars: 5,
    },
    {
      name: "Aisha Johnson",
      role: "Design student, Politecnico di Milano",
      quote: "The personality analysis was eerily accurate. I finally feel like I'm in the right place.",
      stars: 5,
    },
  ];

  const howItWorks = [
    {
      step: "01",
      title: "Take the AI Assessment",
      description: "Answer thoughtfully-crafted questions that feel like a conversation with an expert advisor. Takes about 25 minutes.",
    },
    {
      step: "02",
      title: "AI Analyzes Your Profile",
      description: "Our AI infers hidden traits, detects patterns, and builds a comprehensive psychological, academic, and career profile.",
    },
    {
      step: "03",
      title: "Receive Your Report",
      description: "Get detailed career, course, university, and city recommendations with compatibility scores and personalized reasoning.",
    },
    {
      step: "04",
      title: "Take Action",
      description: "Follow your personalized action plan with specific next steps, deadlines, and resources to make your future happen.",
    },
  ];

  const faqs = [
    {
      q: "How is this different from other career quizzes?",
      a: "Most quizzes match keywords. CareerPilot uses psychological profiling, behavioral analysis, and multi-dimensional matching to understand WHO you are—then recommends where you'll genuinely thrive.",
    },
    {
      q: "How long does the assessment take?",
      a: "About 20-30 minutes. The questions adapt to your answers, so the experience feels like a natural conversation rather than a form.",
    },
    {
      q: "Is my data private?",
      a: "Absolutely. Your responses are encrypted and never shared. You can delete your data at any time.",
    },
    {
      q: "How accurate are the recommendations?",
      a: "Our matching algorithm considers 50+ dimensions of compatibility. Student satisfaction with our recommendations is above 92%.",
    },
    {
      q: "Can I retake the assessment?",
      a: "Yes! People change, and so should your recommendations. You can retake the assessment anytime to get updated results.",
    },
  ];

  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="relative overflow-hidden">
      {/* ── Background Orbs ── */}
      <FloatingOrb className="w-96 h-96 bg-brand-500 top-20 -left-48 animate-float" />
      <FloatingOrb className="w-80 h-80 bg-accent-500 top-96 -right-40 animate-float" style={{ animationDelay: "2s" } as React.CSSProperties} />
      <FloatingOrb className="w-64 h-64 bg-brand-700 top-[60rem] left-1/3 animate-float" style={{ animationDelay: "4s" } as React.CSSProperties} />

      {/* ── Navbar ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-sm">P</div>
            <span className="font-bold text-lg tracking-tight">CareerPilot</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-dark-muted">
            <a href="#how-it-works" className="hover:text-white transition-colors">How It Works</a>
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#testimonials" className="hover:text-white transition-colors">Stories</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/quiz" className="btn-primary text-sm !py-2 !px-5">
              Start Free Assessment
            </Link>
          </div>
        </div>
      </nav>

      {/* ── Hero Section ── */}
      <section className="relative pt-32 pb-20 md:pt-44 md:pb-32 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-medium mb-8"
            style={{
              background: "rgba(92, 124, 250, 0.12)",
              border: "1px solid rgba(92, 124, 250, 0.2)",
              color: "rgb(145, 167, 255)",
            }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" />
            AI-Powered Career & University Matching
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.08] mb-6">
            Find the career, course,
            <br />
            university, and city where
            <br />
            <span className="gradient-text">you&apos;ll truly thrive.</span>
          </h1>

          <p className="text-lg md:text-xl text-dark-muted max-w-2xl mx-auto mb-10 leading-relaxed">
            Our AI analyzes your personality, strengths, ambitions, learning style,
            values, and preferences to recommend where you&apos;re most likely to
            succeed—not just academically, but in life.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/quiz"
              className="btn-primary text-base !py-3.5 !px-8 flex items-center gap-2"
            >
              Start My AI Assessment
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Link>
            <a
              href="#how-it-works"
              className="text-dark-muted hover:text-white transition-colors text-sm font-medium flex items-center gap-2 px-6 py-3.5"
            >
              See How It Works
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
              </svg>
            </a>
          </div>

          {/* Trust indicators */}
          <div className="mt-16 flex flex-wrap items-center justify-center gap-8 text-dark-muted text-sm">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              Private & Secure
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-brand-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              25 min assessment
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
              </svg>
              92% satisfaction rate
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats Section ── */}
      <section className="py-16 px-6 border-t border-dark-border">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { value: 50000, suffix: "+", label: "Students Guided" },
            { value: 500, suffix: "+", label: "Universities Analyzed" },
            { value: 2500, suffix: "+", label: "Courses Matched" },
            { value: 92, suffix: "%", label: "Satisfaction Rate" },
          ].map((stat) => (
            <div key={stat.label}>
              <div className="text-3xl md:text-4xl font-extrabold gradient-text">
                <Counter end={stat.value} suffix={stat.suffix} />
              </div>
              <div className="text-dark-muted text-sm mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── How It Works ── */}
      <section id="how-it-works" className="py-20 md:py-32 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
              How CareerPilot Works
            </h2>
            <p className="text-dark-muted text-lg max-w-xl mx-auto">
              Four steps to discovering where you&apos;ll truly thrive.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {howItWorks.map((step, i) => (
              <div key={i} className="glass-card rounded-2xl p-6 relative group hover:scale-[1.02] transition-transform duration-300">
                <div className="text-5xl font-extrabold gradient-text opacity-30 mb-4">{step.step}</div>
                <h3 className="text-lg font-bold mb-2">{step.title}</h3>
                <p className="text-dark-muted text-sm leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section id="features" className="py-20 md:py-32 px-6 relative">
        <FloatingOrb className="w-72 h-72 bg-brand-600 -top-20 right-0 animate-float" />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
              Not another quiz website.
            </h2>
            <p className="text-dark-muted text-lg max-w-xl mx-auto">
              A premium AI-powered platform that truly understands you.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <div
                key={i}
                className="glass-card rounded-2xl p-6 group hover:scale-[1.02] transition-all duration-300"
              >
                <div className="text-3xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                <p className="text-dark-muted text-sm leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Testimonials ── */}
      <section id="testimonials" className="py-20 md:py-32 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
              Students Who Found Their Path
            </h2>
            <p className="text-dark-muted text-lg max-w-xl mx-auto">
              Real stories from students who discovered where they truly belong.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <div key={i} className="glass-card rounded-2xl p-6">
                <Stars count={t.stars} />
                <p className="text-sm leading-relaxed mt-4 mb-6 text-dark-text/80">&ldquo;{t.quote}&rdquo;</p>
                <div>
                  <div className="font-semibold text-sm">{t.name}</div>
                  <div className="text-dark-muted text-xs">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section id="faq" className="py-20 md:py-32 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="glass-card rounded-xl overflow-hidden"
              >
                <button
                  className="w-full text-left p-5 flex items-center justify-between"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  <span className="font-medium text-sm">{faq.q}</span>
                  <svg
                    className={`w-5 h-5 text-dark-muted transition-transform duration-200 shrink-0 ml-4 ${openFaq === i ? "rotate-180" : ""}`}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={2}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-5 text-dark-muted text-sm leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 md:py-32 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="glass-card rounded-3xl p-10 md:p-16 relative overflow-hidden">
            <FloatingOrb className="w-64 h-64 bg-brand-500 -top-32 -right-32" />
            <FloatingOrb className="w-48 h-48 bg-accent-500 -bottom-24 -left-24" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
                Ready to find where you&apos;ll thrive?
              </h2>
              <p className="text-dark-muted text-lg max-w-xl mx-auto mb-8">
                Join 50,000+ students who discovered their ideal career, course,
                university, and city through CareerPilot.
              </p>
              <Link
                href="/quiz"
                className="btn-primary text-base !py-3.5 !px-8 inline-flex items-center gap-2"
              >
                Start My AI Assessment
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="border-t border-dark-border py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-xs">P</div>
            <span className="font-bold tracking-tight">CareerPilot</span>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-dark-muted text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
            <a href="#" className="hover:text-white transition-colors">Blog</a>
          </div>
          <div className="text-dark-muted text-xs">
            © 2025 CareerPilot. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
